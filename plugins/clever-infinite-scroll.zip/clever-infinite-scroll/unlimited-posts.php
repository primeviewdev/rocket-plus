<?php
/**
 * The template for displaying all post page
 **/
 


get_header(); ?>

<main id="post-left-col" class="relative" role="main">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="infinite-container">
                    <?php if (have_posts()) : while (have_posts()) : the_post();

                    $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');
                    $post_categories = wp_get_post_categories( get_the_ID() );
                    $cats = array();
                        
                    foreach($post_categories as $c){
                        $cat = get_category( $c );
                        $cats[] = array( 'name' => $cat->name, 'slug' => $cat->slug );
                    }
                    ?>
                    <article class="infinite-post" style="margin-bottom: 100px;">
                        <img src="<?php echo $featured_img_url;?>" class="img-fluid post-thumbnail mb-3" alt="<?php the_title(); ?>" />
                        <div class="share-links">
                            <ul class="share-link-list">
                                <li class="heading-item">Share</li>
                                <li><a href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" class="share-fb" target="_blank"><span class="fa fa-facebook"></span></a></li>
                                <li><a href="https://twitter.com/intent/tweet?url=<?php the_permalink(); ?>" class="share-twitter" target="_blank"><span class="fa fa-twitter"></span></a></li>
                            </ul>
                        </div>
                        <div class="content-wrap">
                            <h1><?php the_title(); ?></h1>
                            <p><small><?php get_the_date(); ?></small></p>
                            <div class="cat-list-wrap">
                                <p>
                                <?php 
                                foreach($post_categories as $c){
                                    $cat = get_category( $c );
                                    $cat_id = get_cat_ID( $cat->name );
                                    echo '<small><a href="'.get_category_link($cat_id).'">'.$cat->name.'</a></small> ';
                                }
                                ?>
                                </p>
                            </div>
                            <p><?php the_content(); ?></p>
                            <?php previous_post_link('<p class="next-link">%link</p>', '%title', TRUE ); ?>
                        </div>
                        <!-- < ?php next_post_link( '<p class="next-link">%link</p>', '%title', TRUE ); ?> -->
                    </article>
                    <?php
                    endwhile; endif;
                    ?>
                </div>
            </div>
            <div class="col-md-4"></div>
        </div>
    </div>
</main>
<!-- <style>
main#post-left-col {
    background-color: #f6f6f6;
}
article.infinite-post {
    position: relative;
    margin-top: 30px;
    box-shadow: 0px 0px 15px 1px rgba(0,0,0,0.1);
    background-color: #fff;
}
article.infinite-post .content-wrap {
    padding: 10px 15px 30px;
}
article.infinite-post h1 {
    font-size: clamp(24px, 2.5vw, 36px);
}
article.infinite-post h2 {
    font-size: clamp(22px, 2.5vw, 28px);
}
article.infinite-post h3 {
    font-size: clamp(20px, 2.5vw, 24px);
}
article.infinite-post .share-links {
    position: absolute;
    top: 10px;
    left: -70px;
    padding: 10px 10px 0px;
    background-color: #e3e3e3;
}
article.infinite-post .share-links ul {
    list-style: none;
    margin-bottom: 0;
    text-align: center;
    padding-left: 0px;
}
article.infinite-post .share-links .heading-item {
    border-bottom: 1px solid #a5a5a5;
    margin-bottom: 10px;
}
article.infinite-post .share-links a {
    height: 35px;
    width: 35px;
    padding: 7px 5px;
    border-radius: 50%;
    display: block;
    margin: 10px auto;
    background-color: #21ba9e;
    color: #fff;
}
.cat-list-wrap p small:after {
    content: ',';
}
.cat-list-wrap p small:last-child:after {
    content: '';
}
</style> -->
<?php get_footer(); ?>