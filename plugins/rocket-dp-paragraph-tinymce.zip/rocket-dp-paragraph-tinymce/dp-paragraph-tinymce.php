<?php
/**
 * Plugin Name: Rocket Theme - Dropdown Paragraph TinyMCE
 * Plugin URI: http://www.primeview.com
 * Description: Overrides Morphing Search Plugin
 * Version: 1.0
 * Author: Primeview
 * Author URI: https://www.primeview.com
 */
function fixed_dp_paragraph_tinymce() {
		echo "<script type='text/javascript'>
	
		setTimeout(function(){
            jQuery(window).scroll(function() {
				styleAttr = jQuery('.mce-top-part .mce-toolbar-grp').attr('style');
				listAttr = styleAttr.trim().split(' ');
				if(listAttr[1] == 'fixed;') {
					jQuery('.mce-floatpanel').css('position','fixed');
				} else {
					jQuery('.mce-floatpanel').css('position','absolute');
				}
			});
        },5000)
	
		</script>";
	}
	add_action('admin_footer', 'fixed_dp_paragraph_tinymce');
?>