<?php
/**
 * Plugin Name: Rocket Theme - Override Morphing Search
 * Plugin URI: http://www.primeview.com
 * Description: Overrides Morphing Search Plugin
 * Version: 1.0
 * Author: Primeview
 * Author URI: https://www.primeview.com
 */
function overrideMorphing_Search_Plugin() {
    wp_dequeue_script( 'morphing-search' );
    wp_dequeue_style( 'morphing-search' );
    wp_enqueue_style( 'morphing-search', plugin_dir_url( __FILE__ ) . '/assets/css/full-screen-morphing-search.css', array(), false);
    wp_enqueue_script( 'morphing-search', plugin_dir_url( __FILE__ ) . '/assets/js/full-screen-morphing-search.js', array( 'jquery', 'jquery-ui-core', 'jquery-ui-autocomplete' ), '1.0', true );
}
add_action( 'wp_print_scripts', 'overrideMorphing_Search_Plugin' );
?>